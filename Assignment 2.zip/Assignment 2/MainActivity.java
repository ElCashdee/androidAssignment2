package com.example.liamc.loginapp;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // create all View objects and link to Viws in activity_main.xml
        final EditText usernameEditText = (EditText) findViewById(R.id.username_editText);
        final EditText passwordEditText = (EditText)findViewById(R.id.password_editText);
        final TextView attemptCounter = (TextView) findViewById(R.id.attempt_counter_number);
        final Button logInButton = (Button) findViewById(R.id.login_button);

        logInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int counter = Integer.parseInt(attemptCounter.getText().toString());
                String username = "admin", password = "admin";

                if ((usernameEditText.getText().toString().contentEquals(username)) && (passwordEditText.getText().toString().contentEquals(password))) {
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.qub.ac.uk"));
                    startActivity(browserIntent);
                } else {
                    Toast.makeText(MainActivity.this, "Username or password is incorrect", Toast.LENGTH_SHORT).show();
                    counter -= 1;
                    attemptCounter.setText(String.valueOf(counter));
                }

                if (counter == 0) {
                    logInButton.setClickable(false);
                    logInButton.setTextColor(119);
                    Toast.makeText(MainActivity.this, "Too many failed log in attempts", Toast.LENGTH_SHORT).show();
                }



            }
        });




    }
}
